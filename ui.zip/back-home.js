// Classic screens of the original game (advanced options): a small "Inicio" button to go back to the new home screen.
(function () {
    "use strict";
    function add() {
        if (document.getElementById("back-home")) return;
        var a = document.createElement("a");
        a.id = "back-home"; a.href = "inicio.html"; a.setAttribute("aria-label", "Volver al inicio"); a.setAttribute("data-no-i18n", "");
        a.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M4 11 12 4l8 7v9h-5v-6H9v6H4z" fill="currentColor"/></svg><span>Inicio</span>';
        a.style.cssText = "position:fixed;z-index:2147483000;left:calc(8px + var(--safe-l, 0px));bottom:calc(8px + var(--safe-b, 0px));display:flex;align-items:center;gap:6px;" +
            "min-height:44px;padding:0 14px 0 12px;border-radius:22px;background:#10162be6;color:#edf0f8;text-decoration:none;font:600 16px/1 'Barlow Condensed','Arial Narrow',system-ui,sans-serif;" +
            "box-shadow:0 4px 16px #0009;border:1.5px solid #ffffff22;line-height:44px";
        document.body.appendChild(a);
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", add); else add();
})();
