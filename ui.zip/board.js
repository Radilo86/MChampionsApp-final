// Marvel Champions offline — game menu of the board (replaces the side drawers of the desktop game on touch screens).
// Every entry presses the original button of the game, so the game logic is not touched.
(function () {
    "use strict";
    function K() { return window.UIKit; }
    function $(id) { return document.getElementById(id); }
    function rightButtons() { return Array.prototype.slice.call(document.querySelectorAll("#right-side-bar > .button, #right-side-bar > button")); }
    function press(el) { if (el) { el.click(); return true; } return false; }
    var actions = {
        undo: function () { return press($("undo-btn")); },
        redo: function () { var u = $("undo-btn"); var n = u && u.nextElementSibling; while (n && !(n.classList.contains("button") || n.tagName === "BUTTON")) n = n.nextElementSibling; return press(n); },
        pause: function () { return press($("pause-btn")); },
        log: function () { return press(rightButtons()[0]); },
        qload: function () { return press($("load-btn-0")); },
        qsave: function () { var b = rightButtons().filter(function (x) { return !x.classList.contains("debug-only") && !x.id; }); return press(b[b.length - 1]); },
    };
    function paused() { return document.body.classList.contains("pause"); }
    function drawers(open) {
        document.body.classList.toggle("mv-drawer", open);
        ["right-side-bar", "left-side-bar"].forEach(function (id) { var el = $(id); if (el) el.classList.toggle("open", open); });
    }
    function open() {
        var k = K(); if (!k) { drawers(!document.body.classList.contains("mv-drawer")); return; }
        if (document.body.classList.contains("mv-drawer")) { drawers(false); return; }
        var m = k.sheet("Partida"); m.box.parentNode.classList.add("board-menu");
        function item(ico, title, sub, fn) {
            return k.el("button", { "class": "t-item", type: "button", onclick: function () { m.close(); fn(); } },
                [k.el("span", { "class": "ico", text: ico }), k.el("span", {}, [title, sub ? k.el("small", { text: sub }) : null])]);
        }
        var shell = null; try { shell = window.parent.marvelShell; } catch (e) {}
        var list = [
            item("▶", "Seguir jugando", null, function () {}),
            item("↶", "Deshacer", "Vuelve a la decisión anterior", actions.undo),
            item(paused() ? "▶" : "❚❚", paused() ? "Reanudar" : "Pausar", paused() ? null : "Se detiene al revelar cartas", actions.pause),
            item("≡", "Registro", "Todo lo que ha pasado", actions.log),
            item("⤓", "Guardado rápido", "Guarda este momento para volver a él", function () {
                if (actions.qsave()) { try { localStorage.setItem("marvel-qsave", String(Date.now())); } catch (e) {} k.toast("Guardado. Vuelve a este momento con «Volver al guardado rápido»."); }
            }),
        ];
        var hasQ = false; try { hasQ = !!localStorage.getItem("marvel-qsave"); } catch (e) {}
        if (hasQ && $("load-btn-0")) list.push(item("⤒", "Volver al guardado rápido", "Deja esta jugada y vuelve al momento guardado", function () {
            if (confirm("¿Volver al guardado rápido? Lo jugado desde entonces se pierde.")) actions.qload();
        }));
        var canRotate = false; try { canRotate = !!(shell && shell.portraitTouch && shell.portraitTouch()); } catch (e) {}
        if (canRotate) list.push(item("⟳", "Girar tablero", null, function () { shell.toggleRotate(); }));
        if (shell && shell.fullscreen) list.push(item("⛶", "Pantalla completa", null, function () { shell.fullscreen(); }));
        list.push(item("⚙", "Más controles", "Los menús originales del juego", function () { drawers(true); }));
        list.push(item("⌂", "Salir al inicio", "La partida queda guardada: retómala con Continuar", function () { location.href = "inicio.html"; }));
        m.body.appendChild(k.el("div", { "class": "t-list" }, list));
    }
    // close the original drawers when tapping the board outside them
    document.addEventListener("click", function (e) {
        if (!document.body.classList.contains("mv-drawer")) return;
        if (e.target.closest && (e.target.closest(".side-bar") || e.target.closest("#mv-toolbar") || e.target.closest("#history"))) return;
        drawers(false);
    }, true);
    window.BoardMenu = { open: open, actions: actions, drawers: drawers };
})();
