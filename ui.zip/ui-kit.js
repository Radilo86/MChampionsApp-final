// Marvel Champions offline — small helpers shared by the new screens (inicio, jugar, mazos, cartas) and the board chrome.
(function () {
    "use strict";
    function api(method, url, body) {
        if (window.MarvelApp) return window.MarvelApp.request(method, url, body || "");
        return fetch(url, { method: method, body: method === "GET" ? undefined : body }).then(function (r) { return r.text().then(function (t) { return { status: r.status, body: t }; }); });
    }
    function get(url) { return api("GET", url).then(function (r) { if (r.status !== 200) throw new Error(r.body || ("HTTP " + r.status)); return r.body; }); }
    function getJson(url) { return get(url).then(JSON.parse); }
    function post(url, data) { return api("POST", url, typeof data === "string" ? data : JSON.stringify(data)); }

    function el(tag, props, children) {
        var e = document.createElement(tag);
        Object.keys(props || {}).forEach(function (k) {
            var v = props[k]; if (v === undefined || v === null || v === false) return;
            if (k === "text") e.textContent = v; else if (k === "html") e.innerHTML = v;
            else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), v);
            else if (k === "class") e.className = v; else if (k === "style") e.style.cssText = v;
            else e.setAttribute(k, v === true ? "" : v);
        });
        (children || []).forEach(function (c) { if (c == null) return; e.appendChild(typeof c === "string" ? document.createTextNode(c) : c); });
        return e;
    }
    function esc(t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; }

    var ICONS = {
        back: '<path d="M15 5 8 12l7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>',
        play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
        close: '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
        plus: '<path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
        minus: '<path d="M5 12h14" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>',
        search: '<circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="m16 16 4.5 4.5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        more: '<circle cx="5" cy="12" r="2.2" fill="currentColor"/><circle cx="12" cy="12" r="2.2" fill="currentColor"/><circle cx="19" cy="12" r="2.2" fill="currentColor"/>',
        menu: '<path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        check: '<path d="m5 12.5 4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>',
    };
    function icon(name) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || "") + "</svg>"; }

    function sheet(title, opts) {
        opts = opts || {};
        var back = el("div", { "class": "t-sheet-back" });
        var body = el("div", { "class": "t-sheet-body" });
        var x = el("button", { "class": "t-btn icon ghost", "aria-label": "Cerrar", html: icon("close"), onclick: close });
        var box = el("div", { "class": "t-sheet", role: "dialog", "aria-label": title }, [el("header", {}, [el("h2", { text: title }), x]), body]);
        back.appendChild(box);
        back.addEventListener("click", function (e) { if (e.target === back) close(); });
        function onKey(e) { if (e.key === "Escape") close(); }
        document.addEventListener("keydown", onKey);
        document.body.appendChild(back);
        function close() { document.removeEventListener("keydown", onKey); if (back.parentNode) back.parentNode.removeChild(back); if (opts.onClose) opts.onClose(); }
        return { body: body, box: box, close: close };
    }
    var toastTimer = 0;
    function toast(text, isError, ms) {
        var t = document.querySelector(".t-toast");
        if (!t) { t = el("div", { "class": "t-toast", role: "status" }); document.body.appendChild(t); }
        t.className = "t-toast" + (isError ? " err" : ""); t.textContent = text;
        clearTimeout(toastTimer); toastTimer = setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, ms || 3200);
    }
    // a card picture: the image pack / imported pictures, or a picture drawn from the card data (service worker)
    function cardImg(id, alt) { return el("img", { "class": "pic", src: String(id || "").split(",")[0], alt: alt || "", loading: "lazy", decoding: "async", draggable: "false" }); }

    // names of the boxes ("1. Core Set" -> "Caja básica")
    var PACK_ES = { "Core Set": "Caja básica", "Weekly Challenges": "Desafíos semanales", "Custom": "Mis escenarios" };
    function packName(key) { var n = String(key || "").replace(/^\d+\.\s*/, ""); return PACK_ES[n] || n; }
    function cleanName(n) { return String(n || "").replace(/^\*\s*/, ""); }
    var ASPECT_ES = { Aggression: "Agresividad", Justice: "Justicia", Leadership: "Liderazgo", Protection: "Protección", Basic: "Básica", "'Pool": "'Pool", Hero: "Héroe", Encounter: "Encuentro", Campaign: "Campaña" };
    var TYPE_ES = { Ally: "Aliado", Event: "Evento", Upgrade: "Mejora", Support: "Apoyo", Resource: "Recurso", Hero: "Héroe", AlterEgo: "Álter ego", Villain: "Villano",
        Minion: "Esbirro", Treachery: "Traición", Attachment: "Accesorio", SideScheme: "Plan secundario", MainScheme: "Plan principal", Obligation: "Obligación",
        Environment: "Entorno", PlayerSideScheme: "Plan secundario de jugador", Challenge: "Desafío", Leader: "Líder", Evidence: "Prueba", Status: "Estado", Insert: "Ficha" };

    // ------------------------------------------------------------- the card catalogue (cards.json + content packs)
    var cardsPromise = null;
    function cards() {
        if (cardsPromise) return cardsPromise;
        cardsPromise = Promise.all([getJson("get_cards_json"), getJson("get_sets_json").catch(function () { return {}; })]).then(function (r) {
            var raw = r[0], sets = r[1], packOf = {}, list = [], byId = {};
            Object.keys(sets).forEach(function (k) { if (sets[k] && sets[k].name) packOf[sets[k].name] = k; });
            Object.keys(raw).forEach(function (code) {
                if (!Array.isArray(raw[code])) return;
                raw[code].forEach(function (c) {
                    if (!c || typeof c !== "object" || !c.card_id) return;
                    c.pack = code; c.packName = packName(packOf[code] || code); c.desc = c.desc || {};
                    c.aspects = String(c.desc.Class || "").split(";").filter(Boolean);
                    byId[c.card_id] = c; list.push(c);
                });
            });
            return { list: list, byId: byId, packs: Object.keys(raw).filter(function (k) { return Array.isArray(raw[k]); }).map(function (k) { return { code: k, name: packName(packOf[k] || k) }; }) };
        });
        return cardsPromise;
    }
    function backOf(id, byId) { var m = /^(.*\d)a$/.exec(id); return m && byId[m[1] + "b"] ? m[1] + "b" : null; }
    function frontOf(id, byId) { var m = /^(.*\d)b$/.exec(id); return m && byId[m[1] + "a"] ? m[1] + "a" : null; }
    // card text: keep the game's <b>/<i>/<br>, drop any other markup
    function cardText(t) {
        return esc(t || "").replace(/&lt;(\/?)(b|i|em|strong|br)\s*\/?&gt;/gi, "<$1$2>").replace(/\n/g, "<br>");
    }
    var STAT = [["Cost", "Coste"], ["ATK", "Ataque"], ["THW", "Frustrar"], ["DEF", "Defensa"], ["REC", "Recuperación"], ["SCH", "Plan"], ["HP", "Vida"], ["HS", "Mano"],
        ["StartingThreat", "Amenaza inicial"], ["TargetThreat", "Amenaza objetivo"], ["Boost", "Potenciación"], ["RES", "Recursos"]];
    var RES_ES = { R: "físico", B: "mental", Y: "energía", W: "comodín" };
    function cardSheet(card, data, extra) {
        var m = sheet(cleanName(card.name) || card.card_id);
        var cur = card.card_id;
        var img = el("img", { src: cur, alt: "", style: "width:100%;border-radius:12px;background:var(--ink-3);display:block" });
        var flipId = backOf(cur, data.byId) || frontOf(cur, data.byId);
        var info = el("div", { style: "min-width:0" });
        function fill(c) {
            info.textContent = "";
            var aspect = c.aspects.map(function (a) { return a === "Hero" ? "Carta de héroe" : (ASPECT_ES[a] || a); }).join(", ");
            info.appendChild(el("p", { "class": "t-note", style: "margin:0 0 6px", text: [TYPE_ES[c.type] || c.type, aspect, c.subtitle].filter(Boolean).join(", ") }));
            var stats = el("div", { style: "display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px" });
            STAT.forEach(function (s) {
                var v = c.desc[s[0]]; if (v === undefined || v === "") return;
                if (s[0] === "RES") v = String(v).split("").map(function (x) { return RES_ES[x] || x; }).join(" + ");
                stats.appendChild(el("span", { "class": "mod", style: "padding:4px 9px;border-radius:8px;background:var(--ink-3);font:600 15px var(--display)", text: s[1] + " " + v }));
            });
            if (stats.children.length) info.appendChild(stats);
            if (c.traits && c.traits.length) info.appendChild(el("p", { style: "margin:0 0 6px;font:600 15px var(--display);color:var(--just)", text: c.traits.map(function (t) { return t.charAt(0) + t.slice(1).toLowerCase(); }).join(". ") + "." }));
            if (c.text) info.appendChild(el("p", { style: "margin:0 0 8px;line-height:1.45", html: cardText(c.text) }));
            info.appendChild(el("p", { "class": "t-note", style: "margin:0", text: c.packName + (c.set_name ? ", " + c.set_name : "") + ". Carta " + c.card_id }));
        }
        fill(card);
        var row = el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:12px" });
        if (flipId) row.appendChild(el("button", { "class": "t-btn", type: "button", text: "Ver la otra cara", onclick: function () {
            cur = cur === card.card_id ? flipId : card.card_id; img.src = cur; fill(data.byId[cur]); } }));
        (extra || []).forEach(function (b) { row.appendChild(b); });
        info.appendChild(row);
        var wrap = el("div", { style: "display:grid;grid-template-columns:minmax(150px,240px) minmax(0,1fr);gap:16px;align-items:start" }, [img, info]);
        if (matchMedia("(orientation: portrait) and (max-width: 520px)").matches) wrap.style.gridTemplateColumns = "1fr";
        m.body.appendChild(wrap);
        return m;
    }

    function shell() { try { return window.MarvelApp && window.MarvelApp.shell; } catch (e) { return null; } }
    function go(page) { location.href = page; }

    window.UIKit = { api: api, get: get, getJson: getJson, post: post, el: el, esc: esc, icon: icon, sheet: sheet, toast: toast, cardImg: cardImg,
        packName: packName, cleanName: cleanName, ASPECT_ES: ASPECT_ES, TYPE_ES: TYPE_ES, shell: shell, go: go,
        cards: cards, cardSheet: cardSheet, cardText: cardText, backOf: backOf, frontOf: frontOf };
})();
